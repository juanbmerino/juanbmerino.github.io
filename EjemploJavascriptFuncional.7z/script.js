document.addEventListener("DOMContentLoaded", () => {
  fetch("coins.json")
    .then(response => response.json())
    .then(data => {
      const owned = data.owned;

      document.querySelectorAll("#tabla-monedas tr").forEach(tr => {
        const id = tr.getAttribute("data-id");

        if (id in owned) {
          if (!owned[id]) {
            tr.classList.add("missing");
          } else {
            tr.classList.add("owned");
          }
        } else {
          // Si no aparece en el JSON, considerar como NO tenida
          tr.classList.add("missing");
        }
      });
    })
    .catch(err => console.error("Error cargando coins.json:", err));
});
